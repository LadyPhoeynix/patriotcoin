#!/bin/bash
# create multiresolution windows icon
ICON_SRC=../../src/qt/res/icons/patriotcoin.png
ICON_DST=../../src/qt/res/icons/patriotcoin.ico
convert ${ICON_SRC} -resize 16x16 patriotcoin-16.png
convert ${ICON_SRC} -resize 32x32 patriotcoin-32.png
convert ${ICON_SRC} -resize 48x48 patriotcoin-48.png
convert patriotcoin-16.png patriotcoin-32.png patriotcoin-48.png ${ICON_DST}

